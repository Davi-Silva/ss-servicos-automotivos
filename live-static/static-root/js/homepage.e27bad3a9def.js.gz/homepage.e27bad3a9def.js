let companyWorked = document.querySelectorAll(".company-worked .work-experience-description-container")

companyWorked[0].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[0].style.opacity = "1"
    companyWorked[0].style.transition = "all 0.4s ease-in-out"
})

companyWorked[0].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[0].style.opacity = "0"
    companyWorked[0].style.transition = "all 0.4s ease-in-out"
})

companyWorked[1].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[1].style.opacity = "1"
    companyWorked[1].style.transition = "all 0.4s ease-in-out"
})

companyWorked[1].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[1].style.opacity = "0"
    companyWorked[1].style.transition = "all 0.4s ease-in-out"
})

companyWorked[2].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[2].style.opacity = "1"
    companyWorked[2].style.transition = "all 0.4s ease-in-out"
})

companyWorked[2].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[2].style.opacity = "0"
    companyWorked[2].style.transition = "all 0.4s ease-in-out"
})

companyWorked[3].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[3].style.opacity = "1"
    companyWorked[3].style.transition = "all 0.4s ease-in-out"
})

companyWorked[3].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[3].style.opacity = "0"
    companyWorked[3].style.transition = "all 0.4s ease-in-out"
})

companyWorked[4].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[4].style.opacity = "1"
    companyWorked[4].style.transition = "all 0.4s ease-in-out"
})

companyWorked[4].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[4].style.opacity = "0"
    companyWorked[4].style.transition = "all 0.4s ease-in-out"
})


companyWorked[5].addEventListener('mouseover', () => {
    console.log(companyWorked)
    companyWorked[5].style.opacity = "1"
    companyWorked[5].style.transition = "all 0.4s ease-in-out"
})

companyWorked[5].addEventListener('mouseout', () => {
    console.log(companyWorked)
    companyWorked[5].style.opacity = "0"
    companyWorked[5].style.transition = "all 0.4s ease-in-out"
})


